import Link from "next/link";
import { Plus } from "lucide-react";
import { listClients } from "@/lib/repo/clients.js";
import { requireTenantContext } from "@/lib/saas/context.js";
import { Card, CardHeader, Table, EmptyRow, Badge, Button } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function ClientsPage() {
  const ctx = await requireTenantContext();
  const clients = await listClients(ctx.tenantId);
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-semibold text-zinc-900 dark:text-zinc-100">Clients</h1>
          <p className="text-sm text-zinc-500 dark:text-zinc-400">Business data the AI is allowed to use.</p>
        </div>
        <Link href="/clients/new"><Button><Plus className="h-3.5 w-3.5" /> New client</Button></Link>
      </div>

      <Card>
        <CardHeader
          title={`${clients.length} clients`}
          subtitle={`Plan limit: ${ctx.limits.max_clients < 0 ? "unlimited" : ctx.limits.max_clients}`}
        />
        <Table head={["Business", "Category", "City", "Services", "Keywords", "Posts", "Owner", "GMB", "Status", ""]}
          empty={!clients.length ? <EmptyRow colSpan={10}>No clients yet. Add one to start generating posts.</EmptyRow> : null}>
          {clients.map((c) => (
            <tr key={c.id} className={c.active ? "hover:bg-zinc-50 dark:hover:bg-zinc-800/60" : "bg-zinc-50/60 dark:bg-zinc-800/40 text-zinc-400 dark:text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800"}>
              <td className="px-4 py-2 font-medium text-zinc-800 dark:text-zinc-100">{c.business_name}</td>
              <td className="px-4 py-2 text-zinc-600 dark:text-zinc-400">{c.business_category}</td>
              <td className="px-4 py-2 text-zinc-600 dark:text-zinc-400">{c.city}</td>
              <td className="px-4 py-2 text-zinc-600 dark:text-zinc-400">{c.service_count}</td>
              <td className="px-4 py-2 text-zinc-600 dark:text-zinc-400">{c.keyword_count}</td>
              <td className="px-4 py-2 text-zinc-600 dark:text-zinc-400">{c.post_count}</td>
              <td className="px-4 py-2 text-zinc-600 dark:text-zinc-400">{c.employee_name || "-"}</td>
              <td className="px-4 py-2"><Badge tone="amber">{c.gmb_connection_status}</Badge></td>
              <td className="px-4 py-2">{c.active ? <Badge tone="emerald">Active</Badge> : <Badge tone="red">Inactive</Badge>}</td>
              <td className="px-4 py-2 text-right">
                <Link href={`/clients/${c.id}`} className="text-xs font-medium text-[#F53236] dark:text-brand-400 hover:text-[#e81d22] dark:hover:text-brand-300">Open</Link>
              </td>
            </tr>
          ))}
        </Table>
      </Card>
    </div>
  );
}
