"use client";

import { Fragment, useState } from "react";
import { ChevronDown, ChevronRight, ImageOff } from "lucide-react";
import { Table, EmptyRow, Badge } from "@/components/ui";
import { StatusBadge } from "@/components/status-badge";
import { formatDate, truncate } from "@/lib/utils";

function qaTone(score) {
  if (score == null) return "slate";
  return score >= 80 ? "emerald" : "amber";
}
function hasImage(url) {
  return url && !String(url).startsWith("data:");
}
function list(v) {
  if (!v) return [];
  try {
    const j = JSON.parse(v);
    if (Array.isArray(j)) return j.map((x) => (typeof x === "string" ? x : x?.keyword || x?.tag || JSON.stringify(x)));
  } catch {}
  return String(v).split(/[,\n]/).map((s) => s.trim()).filter(Boolean);
}

export function GmbPostList({ rows }) {
  const [open, setOpen] = useState(null);

  return (
    <Table
      head={["", "Post", "Client / Tenant", "Type", "Status", "QA", "Scheduled", "Published", "Assignee", "Credits"]}
      empty={!rows.length ? <EmptyRow colSpan={10}>No GMB posts match these filters.</EmptyRow> : null}
    >
      {rows.map((r) => {
        const isOpen = open === r.id;
        return (
          <Fragment key={r.id}>
            <tr className="cursor-pointer hover:bg-zinc-50 dark:hover:bg-zinc-800/60" onClick={() => setOpen(isOpen ? null : r.id)}>
              <td className="px-3 py-2 text-zinc-400">
                {isOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
              </td>
              <td className="max-w-xs px-4 py-2">
                <div className="flex items-center gap-2.5">
                  {hasImage(r.image_url) ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={r.image_url} alt="" className="h-10 w-10 shrink-0 rounded-lg object-cover ring-1 ring-zinc-200" />
                  ) : (
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-zinc-100 text-zinc-400 dark:bg-zinc-800">
                      <ImageOff className="h-4 w-4" />
                    </span>
                  )}
                  <div className="min-w-0">
                    <p className="truncate font-medium text-zinc-800 dark:text-zinc-100">{r.title || r.topic || "(untitled)"}</p>
                    <p className="truncate text-xs text-zinc-400">#{r.id}{r.primary_keyword ? ` · ${r.primary_keyword}` : ""}</p>
                  </div>
                </div>
              </td>
              <td className="px-4 py-2 text-xs">
                <p className="font-medium text-zinc-700 dark:text-zinc-200">{r.client_name}</p>
                <p className="text-zinc-400">{r.tenant_name}{r.client_city ? ` · ${r.client_city}` : ""}</p>
              </td>
              <td className="px-4 py-2 text-xs text-zinc-600 dark:text-zinc-400">{r.post_type || "-"}</td>
              <td className="px-4 py-2">
                <div className="flex flex-wrap gap-1">
                  <StatusBadge status={r.status} />
                  {r.post_id ? <Badge tone={r.is_mock ? "amber" : "blue"}>{r.is_mock ? "Mock" : "Live"}</Badge> : null}
                  {r.duplicate_of ? <Badge tone="red">Dup</Badge> : null}
                </div>
              </td>
              <td className="px-4 py-2">{r.qa_score != null ? <Badge tone={qaTone(r.qa_score)}>{r.qa_score}</Badge> : <span className="text-xs text-zinc-400">-</span>}</td>
              <td className="px-4 py-2 text-xs text-zinc-500">{r.scheduled_date ? formatDate(r.scheduled_date) : "-"}</td>
              <td className="px-4 py-2 text-xs text-zinc-500">{r.published_at ? formatDate(r.published_at, true) : "-"}</td>
              <td className="px-4 py-2 text-xs text-zinc-500">{r.employee_name || "-"}</td>
              <td className="px-4 py-2 text-xs text-zinc-600 dark:text-zinc-400">{r.credits_used}</td>
            </tr>

            {isOpen ? (
              <tr className="bg-zinc-50/70 dark:bg-zinc-800/30">
                <td />
                <td colSpan={9} className="px-4 py-4">
                  <div className="grid gap-4 lg:grid-cols-[220px_1fr]">
                    {hasImage(r.image_url) ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={r.image_url} alt="" className="w-full rounded-xl object-cover ring-1 ring-zinc-200" />
                    ) : (
                      <div className="flex aspect-square items-center justify-center rounded-xl bg-zinc-100 text-xs text-zinc-400 dark:bg-zinc-800">No image</div>
                    )}
                    <div className="space-y-3 text-sm">
                      {r.topic ? <p className="text-xs text-zinc-500"><b className="text-zinc-700 dark:text-zinc-300">Topic:</b> {r.topic}</p> : null}
                      <p className="whitespace-pre-line text-zinc-700 dark:text-zinc-200">{r.description || "No description yet."}</p>
                      {r.cta ? <p className="text-xs"><b>CTA:</b> {r.cta}</p> : null}
                      <div className="flex flex-wrap gap-1">
                        {r.primary_keyword ? <Badge tone="indigo">{r.primary_keyword}</Badge> : null}
                        {list(r.secondary_keywords).slice(0, 10).map((k, i) => <Badge key={`k${i}`}>{truncate(k, 40)}</Badge>)}
                      </div>
                      {list(r.hashtags).length ? (
                        <p className="text-xs text-sky-600">{list(r.hashtags).map((h) => (h.startsWith("#") ? h : `#${h}`)).join(" ")}</p>
                      ) : null}
                      <div className="grid gap-x-6 gap-y-1 text-xs text-zinc-500 sm:grid-cols-2 xl:grid-cols-3">
                        <span>Category: {r.business_category || "-"}</span>
                        <span>QA status: {r.qa_status || "-"}</span>
                        <span>Duplicate score: {Number(r.duplicate_score || 0).toFixed(2)}{r.duplicate_of ? ` (of #${r.duplicate_of})` : ""}</span>
                        <span>Regenerated: {r.regenerate_count} · Image regen: {r.image_regen_count}</span>
                        <span>Image: {r.image_provider || "-"}{r.image_storage_provider ? ` → ${r.image_storage_provider}` : ""}</span>
                        <span>Publish: {r.post_id ? `${r.publish_provider}${r.external_id ? ` · ${r.external_id}` : ""}` : "not published"}</span>
                        <span>Created: {formatDate(r.created_at, true)}</span>
                        <span>Updated: {formatDate(r.updated_at, true)}</span>
                      </div>
                      {r.error_message ? <p className="rounded-lg bg-rose-50 px-3 py-2 text-xs text-rose-700">{r.error_message}</p> : null}
                    </div>
                  </div>
                </td>
              </tr>
            ) : null}
          </Fragment>
        );
      })}
    </Table>
  );
}
